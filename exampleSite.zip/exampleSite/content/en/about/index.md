---
title: "About"
description: "I love DS!"
#featured_image: '/images/Victor_Hugo-Hunchback.jpg'
menu:
  main:
    weight: 1
---
<!--{{< figure src="/images/Victor_Hugo-Hunchback.jpg" title="Illustration from Victor Hugo et son temps (1881)" >}}-->

My name is David Thor and I am a Data Scientist! I strive to make a  difference in the world and I believe data-driven decisions. I am highly motivated and driven to go above and beyond in any project. I am extremely passionate about data and would love the opportunity to provide any meaningful insights for your organization. Feel free to reach out and thank you for visiting!
