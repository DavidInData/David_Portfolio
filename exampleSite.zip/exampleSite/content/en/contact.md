---
title: Contact
featured_image: ''
omit_header_text: true
description: We'd love to hear from you
type: page
menu: main

---

Please email me at DavidInData@gmail.com
