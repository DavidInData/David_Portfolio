---
date: 2022-01-22T00:00:00-00:00
description: "Passenger Survivability Prediction on the Titanic"
featured_image: "/images/titanic.jpg"
tags: []
title: "Titanic: Survivability Prediction"
---
- Kaggle Dataset with over 800 Passengers and 11 features
- EDA/Pre-Processing techniques addressing missing values, data imputation, feature engineering
- Utilized GridSearchCV for model optimizatiion
- Analysis using different models such as Gradient Boosting, Random Forest, Logistic regression and more..
- Scored top 16% on Kaggle


- Click  [HERE](https://github.com/DavidInData/Titanic/blob/main/Assignment_3_Part_1.ipynb) for the full analysis using Random Forest
- Click  [HERE](https://github.com/DavidInData/Titanic/blob/main/Assignment2_Part2%20-%20Titanic.pdf) for the full analysis using Logistic Regression, LDA and K-Nearest Neighbor