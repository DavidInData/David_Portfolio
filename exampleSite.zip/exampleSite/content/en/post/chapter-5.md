---
date: 2022-03-06T00:00:00-00:00
description: "Predict whether a tweet is indicating a natural disaster"
featured_image: "/images/tweets.jpg"
tags: []
title: "Natural Language Processing with Disaster Tweets"
---

- Kaggle Dataset with over 7600 tweets
- Utilized pre-processing techniques such as Tokenization and Padding
- Designed Experiment with/without pre-trained word embeddings (GloVe) using Recurrent Neural Network (RNN) with birectional LSTM
- Scored top 16% on Kaggle Leaderboard

- Click  [HERE](https://github.com/DavidInData/Disaster_Tweets/blob/main/Assignment_4_Part_2.ipynb) for the full analysis