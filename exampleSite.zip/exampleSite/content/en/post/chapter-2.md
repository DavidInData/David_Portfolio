---
date: 2022-01-22T00:00:00-00:00
description: "Predicting home prices in Ames, Iowa"
featured_image: "/images/home.jpg"
tags: []
title: "Home Price Prediction"
---


- Analyzed over 1400 home sales with over 80 features
- Utilized data transformation techniques including One-Hot Encoding and Standardization
- K-Fold cross validation with GridSearchCV for hyperparameter optimization
- Utilized regularization methods such as Ridge, Lasso, and ElasticNet
- Scored top 11% on Kaggle

- Click  [HERE](https://github.com/DavidInData/Home-Prices/blob/main/Assignment2_Part1%20-%20Home%20Prices.pdf) for the full analysis

{{< figure src="/images/home.jpg" title="" align="left">}}