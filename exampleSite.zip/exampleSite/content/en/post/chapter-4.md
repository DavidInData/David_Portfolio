---
date: 2022-03-06T00:00:00-00:00
description: "Computer Vision with MNIST data - Predicting Handwritten Digits"
featured_image: "/images/digits.jpg"
tags: []
title: "Digit Recognizer"
---
- Kaggle Dataset of more than 40,000 handwritten digits
- Utilized GridSearchCV for model tuning optimization
- Performed Princial Component Analysis (PCA) to account for 75% of total variation
- Designed Experiments with Multilayer Peceptron (MLP) and Convolutional Neural Networks (CNN)
- Analysis using different Activation Methods and Hidden Layers
- Accuracy score of 98% on test data

- Click  [HERE](https://github.com/DavidInData/Digit-Recognizer/blob/main/Assignment_3_Part_2.pdf) for the full analysis of PCA and K-Means Clustering
- Click  [HERE](https://github.com/DavidInData/Digit-Recognizer/blob/main/Assignment_4_Part_1.ipynb) for the full analysis of MLP & CNN

{{< figure src="/images/digits.jpg" title="" align="left">}}