---
date: 2022-01-01T00:00:00-00:00
description: "EDA Lead-Time/OTD Analysis"
featured_image: "/images/leadtime.jpg"
tags: []
title: "EDA Lead-Time/OTD Analysis"
---
- Does distance have a factor on a Supplier's On-Time Delivery?
- In-depth Exploratory Data Analysis (EDA) on approximately 90000 Purchase Orders
- Various data cleansing techniques such as addressing outliers and missing values
- Feature Engineered Lead-Times, Distances, Receiving Quantites
- Interpretations using HeatMap, Pairplot and more...

- Click  [HERE](https://github.com/DavidInData/Parts-Prediction-EDA/blob/main/Thor_EDA2_FINAL_Project.ipynb) for the full analysis