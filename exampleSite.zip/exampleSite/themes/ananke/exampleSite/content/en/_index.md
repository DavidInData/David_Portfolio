---
title: "Ananke: a Hugo Theme"

description: "The last theme you'll ever need. Maybe."
cascade:
  featured_image: '/images/gohugo-default-sample-hero-image.jpg'
---
Welcome to my blog with some of my work in progress. I've been working on this book idea. You can read some of the chapters below.
